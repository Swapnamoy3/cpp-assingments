/*
Create a STACK class with operation for initialization, push and pop. Support for 
checking underflow and overflow condition are also to be provided. 
*/

#include<iostream>
using namespace std;

class STACK {
    int arr[2];
    int currptr=0;
    public:

        void push(int n){
            if(currptr==2) {printf("Overflow!!!"); return;}
            arr[currptr++]=n;
            
        }

        int pop(){
            if(currptr==0) {printf("UnderFlow!!!");return -1;}
            return arr[currptr--];
        }
};

int main(){
STACK s;
s.push(100);
s.push(100);
s.push(100);
s.pop();
s.pop();
s.pop();
s.pop();
s.pop();
}
