/*
Design a BALANCE class with account number, balance and date of last update. 
Consider a TRANSACTION class with account number, date of transaction, 
amount and transaction type (W for withdrawal and D for deposit). If it is a 
withdrawal check whether the amount is available or not. Transaction object will 
make necessary update in the BALANCE class.
*/
#include<iostream>
using namespace std;

class BALANCE{
    int acc_number;
    int balance=0;
    int date;

};

class Trans